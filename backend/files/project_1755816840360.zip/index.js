Vamos criar um projeto backend básico utilizando o framework Express em JavaScript. A estrutura do projeto será organizada em diferentes pastas e arquivos conforme especificado, e um middleware para tratamento de erros também será incluído. Vamos começar!

### Estrutura do Projeto

```
/seu-projeto
|-- /controllers
|   |-- helloController.js
|   |-- echoController.js
|
|-- /routes
|   |-- helloRoute.js
|   |-- echoRoute.js
|
|-- /middleware
|   |-- errorHandler.js
|
|-- package.json
|-- server.js
```

### Passo 1: Inicializar o Projeto

1. **Inicialize o projeto e instale as dependências**

   No terminal, navegue até a pasta onde você deseja criar o novo projeto e execute:

   ```bash
   mkdir seu-projeto
   cd seu-projeto
   npm init -y
   npm install express
   ```

2. **Criar o arquivo `package.json`**

   O comando `npm init -y` cria automaticamente um arquivo `package.json`. Edite-o para adicionar um script de execução:

   ```json
   {
     "name": "seu-projeto",
     "version": "1.0.0",
     "description": "",
     "main": "server.js",
     "scripts": {
       "start": "node server.js"
     },
     "dependencies": {
       "express": "^4.18.2"
     }
   }
   ```

### Passo 2: Criar a Estrutura de Pastas e Arquivos

1. **Criar a pasta e o arquivo do servidor**

   **server.js**
   
   ```javascript
   const express = require('express');
   const helloRoute = require('./routes/helloRoute');
   const echoRoute = require('./routes/echoRoute');
   const errorHandler = require('./middleware/errorHandler');

   const app = express();

   // Middleware para processar JSON
   app.use(express.json());

   // Rotas
   app.use('/api/hello', helloRoute);
   app.use('/api/echo', echoRoute);

   // Middleware de tratamento de erros
   app.use(errorHandler);

   const PORT = 3000;
   app.listen(PORT, () => {
     console.log(`Servidor rodando na porta ${PORT}`);
   });
   ```

2. **Criar as rotas**

   **/routes/helloRoute.js**

   ```javascript
   const express = require('express');
   const { sayHello } = require('../controllers/helloController');

   const router = express.Router();

   router.get('/', sayHello);

   module.exports = router;
   ```

   **/routes/echoRoute.js**

   ```javascript
   const express = require('express');
   const { echo } = require('../controllers/echoController');

   const router = express.Router();

   router.post('/', echo);

   module.exports = router;
   ```

3. **Criar os controladores**

   **/controllers/helloController.js**

   ```javascript
   exports.sayHello = (req, res) => {
     res.json({ message: "Olá, mundo!" });
   };
   ```

   **/controllers/echoController.js**

   ```javascript
   exports.echo = (req, res) => {
     res.json(req.body);
   };
   ```

4. **Criar o middleware de tratamento de erros**

   **/middleware/errorHandler.js**

   ```javascript
   module.exports = (err, req, res, next) => {
     console.error(err.stack);
     res.status(500).json({ error: 'Algo deu errado!' });
   };
   ```

### Passo 3: Executar o Projeto Localmente

Na pasta raiz do seu projeto, execute:

```bash
npm start
```

Isso deve iniciar o servidor na porta 3000, e você poderá acessar as rotas pelo navegador ou um cliente HTTP, como Postman ou Insomnia.

### Testando as Rotas

- **GET /api/hello**: Deve retornar `{"message": "Olá, mundo!"}`.
- **POST /api/echo**: Deve retornar o JSON que você enviar no corpo da requisição.

Com isso, você tem um projeto backend simples, mas totalmente funcional, usando o Express em JavaScript!