Para um projeto backend completo em JavaScript usando o framework Express, vamos criar uma estrutura organizada que inclui um servidor básico, rotas, middleware para tratamento de erros e um script para execução local. Vamos começar!

### Estrutura do Projeto

```
my-express-app/
├── controllers/
│   ├── helloController.js
│   └── echoController.js
├── routes/
│   ├── helloRoute.js
│   └── echoRoute.js
├── middlewares/
│   └── errorHandler.js
├── app.js
├── package.json
└── README.md
```

### Passo a Passo

#### 1. Inicialize o Projeto e Instale as Dependências

Crie uma nova pasta para o seu projeto e inicialize um novo projeto Node.js, em seguida, instale o Express:

```bash
mkdir my-express-app
cd my-express-app
npm init -y
npm install express
```

#### 2. Crie o `package.json`

O arquivo `package.json` já foi criado com `npm init -y`. Vamos adicionar um script para iniciar o servidor:

```json
{
  "name": "my-express-app",
  "version": "1.0.0",
  "main": "app.js",
  "scripts": {
    "start": "node app.js"
  },
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2"
  }
}
```

#### 3. Crie o Servidor Básico (`app.js`)

```javascript
const express = require('express');
const helloRoute = require('./routes/helloRoute');
const echoRoute = require('./routes/echoRoute');
const errorHandler = require('./middlewares/errorHandler');

const app = express();

// Middleware para parse do JSON
app.use(express.json());

// Rotas
app.use('/api/hello', helloRoute);
app.use('/api/echo', echoRoute);

// Middleware para tratamento de erros
app.use(errorHandler);

// Inicializa o servidor na porta 3000
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
```

#### 4. Crie as Rotas

**`/routes/helloRoute.js`**

```javascript
const express = require('express');
const helloController = require('../controllers/helloController');

const router = express.Router();

router.get('/', helloController.getHelloMessage);

module.exports = router;
```

**`/routes/echoRoute.js`**

```javascript
const express = require('express');
const echoController = require('../controllers/echoController');

const router = express.Router();

router.post('/', echoController.echo);

module.exports = router;
```

#### 5. Crie os Controladores

**`/controllers/helloController.js`**

```javascript
exports.getHelloMessage = (req, res) => {
  res.json({ message: "Olá, mundo!" });
};
```

**`/controllers/echoController.js`**

```javascript
exports.echo = (req, res) => {
  res.json(req.body);
};
```

#### 6. Crie o Middleware de Tratamento de Erros

**`/middlewares/errorHandler.js`**

```javascript
module.exports = (err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Algo deu errado!' });
};
```

### 7. Crie um README.md

O arquivo `README.md` pode conter informações básicas sobre o projeto:

```
# My Express App

Este é um projeto exemplo de um backend em Node.js usando Express.

## Scripts

- `npm start`: Inicia o servidor na porta 3000.

## Rotas

- `GET /api/hello`: Retorna uma mensagem de olá.
- `POST /api/echo`: Retorna o JSON que foi enviado no corpo da requisição.

## Estrutura do Projeto

O projeto está estruturado da seguinte forma:

- `/controllers`: Controladores das rotas.
- `/routes`: Definições das rotas.
- `/middlewares`: Middleware para tratamento de erros.
```

### Execução

Para executar o projeto, use o comando:

```bash
npm start
```

Agora você terá um servidor Express rodando na porta 3000 com as rotas e estrutura solicitada.