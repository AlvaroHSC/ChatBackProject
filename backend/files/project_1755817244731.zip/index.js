Claro! Vamos criar um projeto backend básico usando o Express.js. Este projeto terá a estrutura organizada com as pastas necessárias e conterá todas as declarações de dependências e scripts de execução. Siga os passos abaixo:

### Estrutura do Projeto

```plaintext
my-express-app/
├── package.json
├── server.js
├── /routes
│   ├── index.js
│   ├── hello.js
│   └── echo.js
├── /controllers
│   ├── helloController.js
│   └── echoController.js
├── /middleware
│   └── errorHandler.js
└── /config
    └── default.js
```

### Passo a Passo

1. **Criação da Estrutura de Diretórios**

   Crie as pastas conforme a estrutura acima: `/routes`, `/controllers`, `/middleware`, e `/config`.

2. **Arquivo package.json**

   No diretório raiz `my-express-app`, crie o arquivo `package.json` para definir o projeto e suas dependências:

   ```json
   {
     "name": "my-express-app",
     "version": "1.0.0",
     "description": "Projeto backend com Express",
     "main": "server.js",
     "scripts": {
       "start": "node server.js"
     },
     "dependencies": {
       "express": "^4.18.2"
     }
   }
   ```

3. **Servidor Básico (server.js)**

   Crie um arquivo `server.js` para configurar o servidor Express:

   ```javascript
   const express = require('express');
   const defaultConfig = require('./config/default');
   const errorHandler = require('./middleware/errorHandler');

   const app = express();

   app.use(express.json());

   // Rotas
   const helloRoute = require('./routes/hello');
   const echoRoute = require('./routes/echo');
   app.use('/api/hello', helloRoute);
   app.use('/api/echo', echoRoute);

   // Middleware de tratamento de erros
   app.use(errorHandler);

   // Iniciando o servidor
   app.listen(defaultConfig.port, () => {
     console.log(`Servidor rodando na porta ${defaultConfig.port}`);
   });
   ```

4. **Rotas (routes/index.js)**

   Crie arquivos de rotas para `hello.js` e `echo.js` no diretório `routes`:

   **routes/hello.js**
   ```javascript
   const express = require('express');
   const router = express.Router();
   const helloController = require('../controllers/helloController');

   router.get('/', helloController.sayHello);

   module.exports = router;
   ```

   **routes/echo.js**
   ```javascript
   const express = require('express');
   const router = express.Router();
   const echoController = require('../controllers/echoController');

   router.post('/', echoController.echo);

   module.exports = router;
   ```

5. **Controllers**

   Crie os arquivos de controllers para `helloController.js` e `echoController.js` no diretório `controllers`:

   **controllers/helloController.js**
   ```javascript
   exports.sayHello = (req, res) => {
     res.json({ message: "Olá, mundo!" });
   };
   ```

   **controllers/echoController.js**
   ```javascript
   exports.echo = (req, res) => {
     res.json(req.body);
   };
   ```

6. **Middleware de Tratamento de Erros (middleware/errorHandler.js)**

   Crie um middleware para tratamento de erros:

   **middleware/errorHandler.js**
   ```javascript
   module.exports = (err, req, res, next) => {
     console.error(err.stack);
     res.status(500).json({ error: 'Something went wrong!' });
   };
   ```

7. **Configuração Padrão (config/default.js)**

   Crie um arquivo de configuração `default.js` dentro da pasta `config`:

   **config/default.js**
   ```javascript
   module.exports = {
     port: 3000
   };
   ```

### Executando o Projeto

- Primeiro, instale as dependências do projeto. No terminal, execute:

  ```bash
  npm install
  ```

- Para iniciar o servidor, execute:

  ```bash
  npm start
  ```

O servidor agora estará escutando na porta 3000. Você pode acessar as rotas configuradas, como `GET /api/hello` e `POST /api/echo`. 

Certifique-se de testar usando um cliente HTTP como o Postman ou Insomnia para verificar os endpoints.