Para criar um projeto backend completo em JavaScript usando o framework Express, siga as instruções abaixo. Vamos estruturar o projeto de forma organizada e incluir todas as funcionalidades solicitadas.

### Estrutura de Pastas

```
my-express-app/
├── controllers/
│   ├── echoController.js
│   └── helloController.js
├── routes/
│   ├── echoRoute.js
│   └── helloRoute.js
├── middlewares/
│   └── errorHandler.js
├── index.js
└── package.json
```

### Passo a Passo

#### 1. Inicialize o Projeto

Crie uma nova pasta para seu projeto:

```bash
mkdir my-express-app
cd my-express-app
```

Execute o comando abaixo para inicializar um projeto Node.js e criar o `package.json`:

```bash
npm init -y
```

#### 2. Instale as Dependências

Instale o Express e outras dependências necessárias:

```bash
npm install express
```

#### 3. Configuração do `package.json`

Seu `package.json` deverá se parecer com este:

```json
{
  "name": "my-express-app",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}
```

#### 4. Criação do Servidor (index.js)

Crie um arquivo `index.js` que conterá a configuração do servidor:

```javascript
const express = require('express');
const helloRoute = require('./routes/helloRoute');
const echoRoute = require('./routes/echoRoute');
const errorHandler = require('./middlewares/errorHandler');

const app = express();
const PORT = 3000;

// Middleware para interpretar JSON
app.use(express.json());

// Usar rotas
app.use('/api/hello', helloRoute);
app.use('/api/echo', echoRoute);

// Middleware de tratamento de erros
app.use(errorHandler);

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
```

#### 5. Criar Rotas (Pasta `/routes`)

Crie a pasta `routes` e adicione os arquivos de rotas.

**helloRoute.js**

```javascript
const express = require('express');
const helloController = require('../controllers/helloController');

const router = express.Router();

router.get('/', helloController.getHelloMessage);

module.exports = router;
```

**echoRoute.js**

```javascript
const express = require('express');
const echoController = require('../controllers/echoController');

const router = express.Router();

router.post('/', echoController.echoMessage);

module.exports = router;
```

#### 6. Criar Controladores (Pasta `/controllers`)

Crie a pasta `controllers` e adicione os arquivos de controle.

**helloController.js**

```javascript
exports.getHelloMessage = (req, res) => {
  res.json({ message: "Olá, mundo!" });
};
```

**echoController.js**

```javascript
exports.echoMessage = (req, res) => {
  res.json(req.body);
};
```

#### 7. Middleware de Tratamento de Erros (Pasta `/middlewares`)

Crie a pasta `middlewares` e adicione o middleware de tratamento de erros.

**errorHandler.js**

```javascript
module.exports = (err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Algo deu errado!" });
};
```

#### 8. Executar o Projeto Localmente

Para executar o projeto, use o comando:

```bash
npm start
```

Seu servidor estará rodando na porta 3000 e você poderá testar as rotas:

- Acesse `GET /api/hello` para obter a mensagem "Olá, mundo!"
- Envie um `POST` para `/api/echo` com algum JSON no corpo da requisição para vê-lo retornado.

E está pronto! Você agora tem um backend básico em Express com as funcionalidades especificadas.